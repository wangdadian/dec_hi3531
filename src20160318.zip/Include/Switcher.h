#ifndef SWITCHER_H_
#define SWITCHER_H_

class CSwitcher
{
public:
	CSwitcher();
	~CSwitcher();
	

};


#endif 
