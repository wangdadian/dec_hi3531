#include "switcher.h"


CSwitcher::CSwitcher()
{

}


CSwitcher::~CSwitcher()
{


}







